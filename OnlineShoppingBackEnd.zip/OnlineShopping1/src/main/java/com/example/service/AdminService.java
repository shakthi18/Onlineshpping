package com.example.service;

import java.util.List;

import com.example.PlainJava.AddProduct;
import com.example.PlainJava.Product;
import com.example.PlainJava.RetailerSignUp;
import com.example.exception.CustomerException;
import com.example.pojo.RetailerTable;

public interface AdminService {
	public List<RetailerSignUp> showAllRetailers();
	
	public int addRetailer(RetailerSignUp newRetailer);
	
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer);
	
	public RetailerSignUp getRetailerById(int rId);
	
	public String deleteRetailerById(int rid);
	
	public String deleteProductByrid(int rid);
	
	
}
