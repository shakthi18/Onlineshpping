package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PlainJava.RetailerSignUp;
import com.example.pojo.RetailerTable;
import com.example.repository.RetailerDAO;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private RetailerDAO retailerDAO;
	
	@Override
	public List<RetailerSignUp> showAllRetailers() {
		// TODO Auto-generated method stub
		return this.retailerDAO.showAllRetailers();
	}
	@Override
	@Transactional
	public int addRetailer(RetailerSignUp newRetailer) {
		// TODO Auto-generated method stub
		int id = 0;
		try
		{
			RetailerTable user = this.retailerDAO.getRetailerByEmail(newRetailer.getuEmail());
			return -100;
		}
		catch(NullPointerException e)
		{
			return -100;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			id = this.retailerDAO.addRetailer(newRetailer);
		}
		return id;
	}
	@Override
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer) {
		// TODO Auto-generated method stub
		return this.retailerDAO.updateRetailer(updateRetailer);
	}
	@Override
	public RetailerSignUp getRetailerById(int rId) {
		// TODO Auto-generated method stub
		return this.retailerDAO.getRetailerById(rId);
	}
	@Override
	public String deleteRetailerById(int rid)
	{
		return this.retailerDAO.deleteRetailerById(rid);
	}
	@Override
	public String deleteProductByrid(int rid) {
		
		return this.retailerDAO.deleteProductByrid(rid);
		
	}

}
