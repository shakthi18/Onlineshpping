package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.PlainJava.AddProduct;
import com.example.PlainJava.Cart;
import com.example.PlainJava.ForgotPassword;
import com.example.PlainJava.Login;
import com.example.PlainJava.PlacedOrder;
import com.example.PlainJava.Product;
import com.example.PlainJava.RetailerSignUp;
import com.example.PlainJava.UpdateRetailer;
import com.example.PlainJava.UpdateUser;
import com.example.PlainJava.UserSignUp;
import com.example.PlainJava.Wishlist;
import com.example.exception.CustomerException;
import com.example.pojo.CartTable;
import com.example.pojo.ProductTable;
import com.example.pojo.RetailerTable;
import com.example.pojo.UserTable;
import com.example.service.AdminService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MainController {

	
	
	
	@Autowired
	private AdminService adminService;
	
	
		
	
	@PostMapping(path = "/addNewRetailer") //passed
	public int addNewRetailer(@RequestBody RetailerSignUp newRetailer)
	{
		return this.adminService.addRetailer(newRetailer);
	}
	 
	
	
	 
	@PutMapping(path = "/updateRetailer") //passed
	public RetailerTable updateRetailer(@RequestBody RetailerSignUp updateRetailer)
	{
		return this.adminService.updateRetailer(updateRetailer);
	}
	
	@GetMapping(path = "/showAllRetailers")
	public List<RetailerSignUp> showAllRetailers()
	{
		return this.adminService.showAllRetailers();
	}
	@GetMapping(path = "/getRetailerById/{rId}")
	public RetailerSignUp getRetailerById(@PathVariable String rId)
	{
		return this.adminService.getRetailerById(Integer.parseInt(rId));
	}
	@DeleteMapping(path = "/deleteRetailerById/{rId}")
	public String deleteRetailerById(@PathVariable String rId)
	{
			
		return this.adminService.deleteRetailerById(Integer.parseInt(rId));
	}
	@DeleteMapping(path = "/deleteProductByrid/{rId}")
	public String deleteProductByrid(@PathVariable String rId)
	{
			
		return this.adminService.deleteProductByrid(Integer.parseInt(rId));
	}
	
	
	
	
}
