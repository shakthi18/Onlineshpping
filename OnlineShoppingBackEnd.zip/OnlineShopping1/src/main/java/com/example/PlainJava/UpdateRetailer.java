package com.example.PlainJava;

public class UpdateRetailer {

}
