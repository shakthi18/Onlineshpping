package com.example.repository;

import java.util.List;

import com.example.PlainJava.AddProduct;
import com.example.PlainJava.PlacedOrder;
import com.example.PlainJava.Product;
import com.example.PlainJava.RetailerSignUp;
import com.example.PlainJava.UserSignUp;
import com.example.exception.CustomerException;
import com.example.pojo.RetailerTable;
import com.example.pojo.UserTable;

public interface RetailerDAO {
	public int getRetailerByEmailAndPassword(String email, String password) throws CustomerException;
	public RetailerTable getRetailerByEmail(String email) throws CustomerException;
	public int addRetailer(RetailerSignUp newRetailer);
	public boolean addProduct(AddProduct product, int rId);
	public RetailerTable updateRetailer(RetailerSignUp updateRetailer);
	public AddProduct updateProduct(AddProduct updateProduct, int pId);
	public List<Product> showMyProducts(int rId);
	public List<RetailerSignUp> showAllRetailers();
	public RetailerSignUp getRetailerById(int rId);
	public String deleteRetailerById(int rid);
	public String deleteProductByrid(int rid);
}
