package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.PlainJava.RetailerSignUp;
import com.example.exception.CustomerException;
import com.example.service.AdminServiceImpl;

@SpringBootTest
class OnlineShoppingApplicationTests {

	@Autowired
	AdminServiceImpl adminService = new AdminServiceImpl();
	
	
	@Test
	void deleteRetailer() throws CustomerException{
	 String s=adminService.deleteRetailerById(22);
	 System.out.println(s);
	}
	@Test
	void addNewRetailer() throws CustomerException{
	 RetailerSignUp newRetailer=new RetailerSignUp("JOoojoo", "joo21@gmail.com", "Joo123", "8989898654", 28);
		
	 int s=adminService.addRetailer(newRetailer);
	 System.out.println(s);
	}
	
	@Test
	void contextLoads() {
	}

}
