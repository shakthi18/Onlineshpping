import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminProfileComponent } from './admin-profile/admin-profile.component';
import { AdminRetailersComponent } from './admin-retailers/admin-retailers.component';
import { AdminUpdateComponent } from './admin-update/admin-update.component';
  

const routes: Routes = [
  {path : 'admin-login', component: AdminLoginComponent},
  {path : 'admin-profile', component: AdminProfileComponent},
  {path : 'admin-retailer', component: AdminRetailersComponent},
  {path : 'admin-update', component: AdminUpdateComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
