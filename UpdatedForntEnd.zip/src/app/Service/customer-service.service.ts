import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../admin-login/Login';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  private _tempurl =  'http://localhost:8095/';
  private _url =      'http://localhost:8095/';


  constructor(private _http : HttpClient) { }

  login(login : Login) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'login';
    return this._http.post<number>(this._url,login);
  }
}
