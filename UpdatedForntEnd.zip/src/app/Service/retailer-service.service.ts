import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../admin-login/Login';
import { Retailer } from '../admin-profile/RetailerSignUp';

@Injectable({
  providedIn: 'root'
})
export class RetailerServiceService {

  private _tempurl =  'http://localhost:8095/';
  private _url =      'http://localhost:8095/';
  constructor(private _http : HttpClient) { }

  login(login : Login) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'retailerLogin';
    return this._http.post<number>(this._url,login);
  }
  getRetailerById(rId: string) : Observable<Retailer>
  {
    this._url = this._tempurl;
    this._url += 'getRetailerById/' + rId;
    return this._http.get<Retailer>(this._url);
  }
  addNewRetailer(newRetailer:Retailer) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'addNewRetailer';
    return this._http.post<number>(this._url,newRetailer);
  }
  showAllRetailers() : Observable<Retailer[]>
  {
    this._url = this._tempurl;
    this._url += 'showAllRetailers';
    return this._http.get<Retailer[]>(this._url);
  }
  deleteRetailerById(rid : number) : Observable<string> {//eno is copied here to empNo
    this._url = this._tempurl;
    this._url += 'deleteRetailerById/' + rid;
    return this._http.delete<string>(this._url);
    }
    updateRetailer(newRetailer:Retailer) : Observable<number>
  {
    this._url = this._tempurl;
    this._url += 'updateRetailer';
    return this._http.put<number>(this._url,newRetailer);
  }
}
