export class Retailer
{
    rId : number;
    uName : string;
	uEmail : string;
	uPassword : string;
	uPhone : number;
}